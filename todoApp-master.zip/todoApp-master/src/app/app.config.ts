export const appName: string = 'Todo App';
export const server: string = 'https://asia-southeast1-abidtkg-ef77b.cloudfunctions.net/jsengine';